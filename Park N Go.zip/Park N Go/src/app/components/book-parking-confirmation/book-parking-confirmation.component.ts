import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-parking-confirmation',
  templateUrl: './book-parking-confirmation.component.html',
  styleUrls: ['./book-parking-confirmation.component.scss'],
})
export class BookParkingConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
